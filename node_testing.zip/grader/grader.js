const prompt = require("prompt-sync") ();

const name = prompt("Type your name here: ");
const assignment = prompt("Type an assignment name: ");
const grade = parseFloat(prompt("Enter the grade number for that assignment: "));
const msg = [];

function gradeInfo(){
    if(grade <=100 && grade >=90){
        msg.push(`Hello ${name}\nYour letter grade for ${assignment} assignment is as follows: A\nAssignment details:\nYou have met most or all of the assignment's requirements.`);
        console.log(msg[0])
    }
    else if(grade <90 && grade >=80){
        msg.push(`Hello ${name}\nYour letter grade for ${assignment} assignment is as follows: B\nAssignment details:\nYou have met most of the assignment's requirements.`)
        console.log(msg[0])
    }
    else if(grade <80 && grade >=70){
        msg.push(`Hello ${name}\nYour letter grade for ${assignment} assignment is as follows: C\nAssignment details:\nYou have met many of the assignment's requirements.`)
        console.log(msg[0])
    }
    else if(grade <70 && grade >=60){
        msg.push(`Hello ${name}\nYour letter grade for ${assignment} assignment is as follows: D\nAssignment details:\nYou have met some of the assignment's requirements.`)
        console.log(msg[0])
    }
    else if(grade <60 && grade >=0){
        msg.push(grade)
        console.log(msg[0])
    }
    else{
        msg.push("You did not enter a grade number between 0 and 100.")
        console.log(msg[0])
    }
}
gradeInfo();

module.exports = {name:name, assignment:assignment, grade:grade, msg:msg}