const {name, assignment, msg, grade, gradeInfo} = require('./grader');

describe("Grade numbers should correspond correctly to grade letters", () => {
    test("The letter grade should corresepond to the number grade", () => {

        if(grade >=90 && grade <=100){
            let response = `Hello ${name}\nYour letter grade for ${assignment} assignment is as follows: A\nAssignment details:\nYou have met most or all of the assignment's requirements.`;
            expect(msg[0]).toBe(response)
        }
    })
    test("The letter grade for a number grade <90 and >=80 should be a B", () => {
        if(grade <90 && grade >=80){
            let response = `Hello ${name}\nYour letter grade for ${assignment} assignment is as follows: B\nAssignment details:\nYou have met most of the assignment's requirements.`;
            expect(msg[0]).toBe(response)
        }
    })
    test("The letter grade for a number grade <80 and >=70 should be a C", () => {
        if(grade <80 && grade >=70){
            let response = `Hello ${name}\nYour letter grade for ${assignment} assignment is as follows: C\nAssignment details:\nYou have met many of the assignment's requirements.`;
            expect(msg[0]).toBe(response)
        }
    })
    test("The letter grade for a number grade <70 and >=60 should be a D", () => {
        if(grade <70 && grade >=60){
            let response = `Hello ${name}\nYour letter grade for ${assignment} assignment is as follows: D\nAssignment details:\nYou have met some of the assignment's requirements.`;
            expect(msg[0]).toBe(response)
        }
    })
    test("The letter grade for a number grade <60 and >=0 should be just the number grade", () => {
        if(grade <60 && grade >=0){
            let response = grade
            expect(msg[0]).toBe(response)
        }
    })
    test("The response for a number grade >100 or <0 should be an error message", () => {
        if(grade >100 || grade <0){
            let response = "You did not enter a grade number between 0 and 100."
            expect(msg[0]).toBe(response)
        }
    })
})

describe("Message response should be defined", () => {
    test("Any response that is not undefined passes", () => {
        expect(msg[0]).toBeDefined()
    })
})







